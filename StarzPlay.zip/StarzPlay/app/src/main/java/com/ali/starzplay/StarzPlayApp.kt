package com.ali.starzplay

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class StarzPlayApp : Application()