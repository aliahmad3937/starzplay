package com.ali.starzplay.core

import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleCoreUnitTest {
    @Test
    fun sampleTest() {
        assertTrue(true)
    }
} 